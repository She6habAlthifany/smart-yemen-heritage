# Smart Yemen Heritage

AI & AR-based Encyclopedia for Ancient Yemeni History.