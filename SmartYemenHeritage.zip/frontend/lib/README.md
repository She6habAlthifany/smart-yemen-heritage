# frontend/lib

This folder is part of the Smart Yemen Heritage project.
