# ai_module/dataset

This folder is part of the Smart Yemen Heritage project.
